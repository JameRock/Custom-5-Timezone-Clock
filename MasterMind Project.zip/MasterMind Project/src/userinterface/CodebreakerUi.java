package userinterface;

import constants.Constants;
import core.Codebreaker;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 */
public class CodebreakerUi 
{
    private JPanel codebreakerAttempt;
    private JPanel codebreakerColors;
    private RoundButton[] buttons;
    private RoundButton[][] attempts;
    
    private Codebreaker codebreaker;
    private Color colorSelected;
    
    private ButtonColorListener buttonColorListener;
    
    public CodebreakerUi(Codebreaker codebreaker)
    {
        this.codebreaker = codebreaker;
        initComponents();
    }
    
    private void initComponents()
    {
        
        codebreakerAttempt = new JPanel();
        codebreakerAttempt.setMinimumSize(new Dimension(50, 25));
        codebreakerAttempt.setPreferredSize(new Dimension(180, 50));
        codebreakerAttempt.setBorder(BorderFactory.createTitledBorder("Codebreaker Attempt"));
        
        codebreakerColors = new JPanel();
        codebreakerColors.setMinimumSize(new Dimension(50, 25));
        codebreakerColors.setPreferredSize(new Dimension(200,75));
        codebreakerColors.setBorder(BorderFactory.createTitledBorder("Codebreaker Attempt"));
        
        codebreakerColors.setLayout(new FlowLayout());
        buttons = new RoundButton[8];
        
        int i, k;
        
        for(i = 0; i<8; i++)
        {
            
            buttons[i] = new RoundButton();
            Color newColor = constants.Constants.codeColors.get(i);
            buttons[i].setBackground(newColor);
            buttons[i].putClientProperty("color", newColor);
            
            buttons[i].setToolTipText(newColor.toString());
            buttons[i].addActionListener(new colorListener());
            codebreakerColors.add(buttons[i]);
        }
        
        codebreakerAttempt.setLayout(new GridLayout(10,4));
        attempts = new RoundButton[10][4];
        
        for(i = 0; i<10; i++) {
            for (k = 0; k <4; k++) {
                attempts[i][k] = new RoundButton();
                attempts[i][k].putClientProperty("row", i+1);
                attempts[i][k].addActionListener(new attemptListener());
                if (i!=9) {
                    attempts[i][k].setEnabled(false);
                }
                
                codebreakerAttempt.add(attempts[i][k]);
                
            }
            
            
        }
        
        
        
        initCodebreakerColors();
        initCodebreakerAttempt();
    }
    
    private void initCodebreakerColors()
    {
        codebreakerColors = new JPanel();
        codebreakerColors.setBorder(BorderFactory.createTitledBorder("Codebreaker Colors"));
        codebreakerColors.setMinimumSize(new Dimension(200, 65));
        codebreakerColors.setPreferredSize(new Dimension(200,65));
        
        // instantiate the Array with the size
        buttons = new RoundButton[Constants.COLORS];
        
        // counter for enhanced for loop
        int counter = 0;
        
        // put client properties on the buttons so we
        // know which one it is
        for (RoundButton button : buttons) 
        {			
            // create the buttons
            button = new RoundButton();
            Color color = Constants.codeColors.get(counter);
            button.setBackground(color);
            button.putClientProperty("color", color);
            button.putClientProperty("row", button);
            
            // set the tooltip
            if(color == Color.BLUE)
                button.setToolTipText("BLUE");
            else if(color == Color.BLACK)
                button.setToolTipText("BLACK");
            else if(color == Color.GREEN)
                button.setToolTipText("GREEN");
            else if(color == Color.ORANGE)
                button.setToolTipText("ORANGE");
            else if(color == Color.PINK)
                button.setToolTipText("PINK");
            else if(color == Color.RED)
                button.setToolTipText("RED");            
            else if(color == Color.YELLOW)
                button.setToolTipText("YELLOW");
            else if(color == Color.WHITE)
                button.setToolTipText("WHITE");
                        
            // add an ActionListener
            button.addActionListener(new ButtonColorListener());
            
            // add button to JPanel using FlowLayout
            codebreakerColors.add(button);
            
            // increment the counter
            counter++;
        }	
    }
    
    private void initCodebreakerAttempt()
    {
        codebreakerAttempt = new JPanel();
        codebreakerAttempt.setBorder(BorderFactory.createTitledBorder("Codebreaker Attempt"));
        codebreakerAttempt.setMinimumSize(new Dimension(100, 100));
        codebreakerAttempt.setPreferredSize(new Dimension(100, 100));
        
        // set the layout manager to use GridLayout
        codebreakerAttempt.setLayout(new GridLayout(Constants.MAX_ATTEMPTS, Constants.MAX_PEGS));
        
        // instantiate the Array with the size
        attempts = new RoundButton[Constants.MAX_ATTEMPTS][Constants.MAX_PEGS];
        
        // create the array of JButtons for the code breaker's attempts
        for (int row = 0; row < Constants.MAX_ATTEMPTS; row ++) 
        {			
            for(int col = 0; col < Constants.MAX_PEGS; col++)
            {
                // create the buttons
                attempts[row][col] = new RoundButton();
                
                // if it isn't the first row then disable the button
                if(row != (Constants.MAX_ATTEMPTS - 1))
                    attempts[row][col].setEnabled(false);
                
                // add the button to the UI
                codebreakerAttempt.add(attempts[row][col]);
            }
        }
    }

    /**
     * @return the codebreakerAttempt
     */
    public JPanel getCodebreakerAttempt() 
    {
        return codebreakerAttempt;
    }

    /**
     * @return the codebreakerColors
     */
    public JPanel getCodebreakerColors() 
    {
        return codebreakerColors;
    }
    
    
    public void setCodebreakerColors(JPanel codebreakerColors) {
        this.codebreakerColors = codebreakerColors;
    }

    void clearBoard() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static class ButtonColorListener implements ActionListener {

        public ButtonColorListener() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
    
    class colorListener implements ActionListener {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            
            RoundButton press = (RoundButton) (e.getSource());
            colorSelected = (Color)press.getClientProperty("color");
        }
    }
    
    class attemptListener implements ActionListener {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            RoundButton press = (RoundButton) (e.getSource());
            
            //system.out will print codebreaker.getcodebreakerAttempt()
            if(!(codebreaker.getCodebreakerAttempt().contains(colorSelected))) {
                press.setBackground(colorSelected);
                ArrayList<Color> newItem = codebreaker.getCodebreakerAttempt();
                newItem.add(colorSelected);
                codebreaker.setCodebreakerAttempt(newItem);
            }
            
            if(!(codebreaker.getCodebreakerAttempt().contains(colorSelected))) {
                press.setBackground(colorSelected);
                ArrayList<Color> newItem = codebreaker.getCodebreakerAttempt();
                newItem.add(colorSelected);
                codebreaker.setCodebreakerAttempt(newItem);
            }
            
            if (codebreaker.getCodebreakerAttempt().size() == Constants.MAX_PEGS) { 
                int i = (int)press.getClientProperty("row");
                
                enableDisableButtons(i);
            }
        }
    private void enableDisableButtons(int row) {
        int i, k;
        for (i = 0; i <4; i++) {
            attempts[row-1][i].setEnabled(false);
            codebreakerAttempt.add(attempts[row-1][i]);
        }
        if (row != 1) {
            for (i = 0; i <4; i++) {
                attempts[row-2][i].setEnabled(true);
                codebreakerAttempt.add(attempts[row-2][i]);
                
            }
        }
         codebreaker.removeAll(); // removes all 
        
    }
    public void clearBoard() {
        int i = 0, k;
        
        for (k = 0; k <4; k++) {
            attempts[i][k].setBackground(null); // sets background null
            if (i!=9) {
                attempts[i][k].setEnabled(false); //set enabled false
            }
            codebreakerAttempt.add(attempts[i][k]);
            
            }
        codebreaker.removeAll();
       
        
        }
    
    
    
    
    
    }
    
    
  
    
    
    }
  